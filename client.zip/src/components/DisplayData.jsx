import React from "react";
import moment from "moment";

export default function DisplayData({ data }) {
  const { nom, prenom, email, heure_debut, heure_fin } = data;

  return (
    <tr>
      <td>{nom}</td>
      <td>{prenom}</td>
      <td>{email}</td>
      <td>{moment(heure_debut).format("HH:mm")}</td>
      <td>{moment(heure_fin).format("HH:mm")}</td>
    </tr>
  );
}
