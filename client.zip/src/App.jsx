import { useEffect, useState } from "react";
import axios from "axios";
import "./App.css";
import Enregistrement from "./components/Enregistrement";
import Home from "./components/Home";

function App() {
  return (
    <>
      <Home />
      {/* <Enregistrement /> */}
    </>
  );
}

export default App;
